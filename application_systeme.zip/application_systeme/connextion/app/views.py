from distutils.log import error
from email import message
from tokenize import generate_tokens
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from connextion import settings
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode , urlsafe_base64_decode
from django.utils.encoding import force_bytes,force_text
from django.core.mail import send_mail,EmailMessage
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from .token import generatorToken


def home(request):
    return render (request ,'app/index.htm')

def register(request):
    if request.method =="POST":
        Username = request.POST['Username']
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        Username = request.POST['Username']
        email = request.POST['e-mail']
        password = request.POST['password']
        password1 = request.POST['password1']
        if User.objects.filter(username=Username):
            messages.error(request, 'ce non est deja utiliser')
            return redirect('register')
        if User.objects.filter(email=email):
            messages.error(request,'cet email existe deja')
            return redirect('register')        
        if not Username.isalnum():
            messages.error(request,'le nom doit etre composee  que des lettres')
            return redirect('register')        
        if password != password1:
            messages.error(request,'les deux password sont differents')
            return redirect('app/register.html')


        mon_utilisateur = User.objects.create_user(Username,email,password)
        mon_utilisateur.first_name = firstname
        mon_utilisateur.last_name =lastname
        mon_utilisateur.is_active = False
        mon_utilisateur.save()
        messages.success(request, 'votre compte a ete cree avec success')
        #envoi d'email de bienvenue
        subject = 'Bienvenue sur la page de ange je vous remercie'
        message = "Bienvenue "+ mon_utilisateur.first_name + " " + mon_utilisateur.last_name + "\n Nous somme heureux de vous compter parmis nous \n\n\n Merci!!\n\n yeo ange"
        from_email = settings.EMAIL_HOST_USER 
        to_list = [mon_utilisateur.email]
        send_mail(subject , message , from_email , to_list, fail_silently=False)
#email de comfirmation
        current_site = get_current_site(request)
        email_subject = "confirmer l'address email sur yeo ange"
        messageconfirm = render_to_string("emailconfirm.html", {
            "mame":mon_utilisateur.first_name,
            "domain":current_site.domain,
            "uid":urlsafe_base64_encode(force_bytes(mon_utilisateur.pk)),
            'token': generatorToken.make_token(mon_utilisateur)
        })

        email = EmailMessage(
            email_subject,
            messageconfirm,
            settings.EMAIL_HOST_USER,
            [mon_utilisateur.email]
        )
        email.fail_silently = False
        email.send()
        return redirect('login')
    return render(request,'app/register.html')


def logIn(request):
    if request.method =="POST":
        Username = request.POST['Username']
        password = request.POST['password']
        User = authenticate(Username=Username, password=password)
        my_user = User.objects.get(Username=Username)
        if User is not None:
            login(request,User)
            firstname = User.first_name
            return render(request, 'app/index.htm',{'firstname':firstname})
        elif  my_user.is_active == False:
            messages.error(request, "vous n'avew pasconfirmer votre address email faite le avant de vous connecter")    
        else:
            messages.error(request,'mauvaise authentification')
            return redirect('login')
    return render(request, 'app/login.html')
       


def logOut(request):
    logout(request)
    messages.success(request,'vous vous etes deconnecte')
    return redirect('login')




def activate(request , uidb64 , token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        User = User.objects.get(pk=uid)
    except(TypeError , ValueError , OverflowError , User.DoesNotExist):
        User = None
    if User is not None and generatorToken.check_token(User,token):
        User.is_active = True 
        User.save()
        messages.success(request,"votre compte a ete activer felicitation connecter vous maintenant")
        return redirect('login')
    else:
        messages.error(request,"l'activation a echoue")
        return redirect('home') 

def new_func(uid):
    User= User.objects.get(pk=uid)
    return User   

